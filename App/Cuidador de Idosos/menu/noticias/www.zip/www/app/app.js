angular.module('organograma', 
	['ngMaterial',
	'ngRoutes',
	'organograma.home'])
    .config(config);

function config($routeProvider) {
    $routeProvider
        .when('/home', {
            templateUrl: 'views/home/index.html',
            controller: 'HomeController',
            controllerAs: 'vmHomeCtrl	'
        })
      .otherwise({redirectTo: '/home'});
}