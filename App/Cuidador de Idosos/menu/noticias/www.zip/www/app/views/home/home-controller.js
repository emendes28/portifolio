angular.module('organograma.home', [])
		.controller('HomeController',HomeController);

function HomeController(){
	vmHomeController = this;
	
}