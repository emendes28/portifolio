var toggleView = {
  init: function() {
    toggleView.triggers();
    toggleView.load();
  },
  triggers: function() {
    $(".js-toggle-view").click(toggleView.toggle);
  },
  load: function() {
    var hiddenList = [],
        hiddenGrid = [],
        x, y = 0;
    
    $(".list-grid").find("[data-hide]").each(function() {
      var type = $(this).data("hide");
      if (type === "grid") {
        hiddenGrid[x] = $(this).index();
        x += 1;
      }
      else if (type === "list") {
        hiddenList[y] = $(this).index();
        y += 1;
      }
    });
    
    $(".list-grid .item").each(function() {
      for (x in hiddenList) {
      	toggleView.setHidden($(this), hiddenList[x], "list");
      }
      for (x in hiddenGrid) {
        toggleView.setHidden($(this), hiddenGrid[x], "grid");
      }
    });
  },
  setHidden: function(item, index, type) {
    item.find(".cell:eq(" + index + ")").addClass("hidden-" + type);
  },
  toggle: function() {
    var grid = $(this).closest(".example").find(".list-grid");
    $(this).toggleClass("list grid");
    grid.toggleClass("grid-view list-view");
  } 
};
$(document).ready(toggleView.init);