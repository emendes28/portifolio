angular.module('organogramaAngular', 
	['ngMaterial',
    'ngAnimate',
    'firebase',
	'ngRoute',
	'organogramaAngular.login',
    'organogramaAngular.home'])
    .config(config);

function config($routeProvider) {
    $routeProvider
        .when('/login', {
            templateUrl: 'login.html',
            controller: 'LoginController',
            controllerAs: 'vmLogin'
        })
        .when('/home/:id', {
            templateUrl: 'home.html',
            controller: 'HomeController',
            controllerAs: 'vmHome',
            resolve: {
              // I will cause a 1 second delay
              delay: function($q, $timeout) {
                var delay = $q.defer();
                $timeout(delay.resolve, 1000);
                return delay.promise;
              }
            }
        })
      .otherwise({redirectTo: '/login'});
}