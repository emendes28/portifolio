var app = angular.module("organogramaAngular.login", [])
  .factory("Auth", AuthFactory)
  .controller("LoginController", LoginCtrl)
  .config(function($mdThemingProvider) {
    $mdThemingProvider.theme('docs-dark').dark();
  });

// let's create a re-usable factory that generates the $firebaseAuth instance
AuthFactory.$inject = ["$firebaseAuth"];
function AuthFactory($firebaseAuth) {
  var ref = new Firebase("https://organograma.firebaseio.com/");
  return $firebaseAuth(ref);
}

// and use it in our controller
LoginCtrl.$inject = ["$log","$location", "Auth","$mdDialog"];
function LoginCtrl($log,$location, Auth,$mdDialog) {
  vmLogin = this;
  vmLogin.message = null;
  vmLogin.error = null;
  vmLogin.isLoggedIn = false;
  vmLogin.createUser = createUser;
  vmLogin.login = login;
  var offAuth = Auth.$onAuth(onAuth);
  
  init();

  function init() {
    vmLogin.message = null;
    vmLogin.error = null;
  }
  
  function onAuth(authData){
    $log.info("ONAUTH", authData)
  }

  function createUser(ev) {

    if(!validar(ev)){
      return false;
    }
    init();
    Auth.$createUser({
      email: vmLogin.user.email,
      password: vmLogin.user.password
    }).then(function(userData) {
      showAlert (ev, 
        "Registro", 
         "Usuario Criado com sucesso !", 
        "Ok", 
        "Criar usuario") ;
      vmLogin.message = "Usuario Criado com sucesso !"
     }).catch(function(error) {
      showAlert (ev, 
        "Erro", 
        error.message, 
        "Corrigir", 
        "Erro ao criar usuario") ;
    });
  };


  function login(ev) {
    if(!validar(ev)){
      return false;
    }
    init();
    Auth.$authWithPassword({
      email: vmLogin.user.email,
      password: vmLogin.user.password
    }).then(function(authData) {
      $location.path("/home/"+authData.uid);
      /*vmLogin.isLoggedIn = true;
      /*vmLogin.message = "Authenticated successfully with payload:";
      console.log(vmLogin.message, authData);*/
    }).catch(function(error) {
      showAlert (ev, 
        "Erro", 
        error.message, 
        "Corrigir", 
        "Erro ao logar") ;
    });
  }


function validar(ev){

    if(vmLogin.user === undefined){
      showAlert (ev, 
        "Atencao", 
         "Favor informar email e senha", 
        "Certo", 
        "Criar usuario") ;
      return false;
    } else if(vmLogin.user.email === undefined){
      showAlert (ev, 
        "Atencao", 
         "Favor informar email", 
        "Certo", 
        "Criar usuario") ;
      return false;
    } else if(vmLogin.user.password === undefined){
      showAlert (ev, 
        "Atencao", 
         "Favor informar senha", 
        "Certo", 
        "Criar usuario") ;  
      return false;
    } 
}
  function showAlert (ev, title, content, botaoOk, label) {
    // Appending dialog to document.body to cover sidenav in docs app
    // Modal dialogs should fully cover application
    // to prevent interaction outside of dialog
    $mdDialog.show(
      $mdDialog.alert()
        .parent(angular.element(document.querySelector('#popupContainer')))
        .clickOutsideToClose(true)
        .title(title)
        .textContent(content)
        .ariaLabel(label)
        .ok(botaoOk)
        .targetEvent(ev)
    );
  };
}