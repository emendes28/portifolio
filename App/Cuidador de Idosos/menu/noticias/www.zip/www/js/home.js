angular.module('organogramaAngular.home', [])
    .controller('HomeController',HomeCtrl);

function HomeCtrl($firebase,$mdDialog,$routeParams){

    //Variaveis
    vmHome = this; 
    vmHome.data = [];
    vmHome.diasDaSemana=[];
    vmHome.ref = {};
    vmHome.sync = {};
    vmHome.tarefa = {};    

    //Metodos    
    vmHome.adicionar = adicionar;
    vmHome.excluir = excluir;
    vmHome.editar = editar;      
    vmHome.fecharModal = fecharModal;
    vmHome.init = init();
    vmHome.mostrarModal = mostrarModal;

    function init(){
        vmHome.ref = new Firebase("https://organograma.firebaseio.com/"+$routeParams.id);
        vmHome.ref.on("value", function(snap) {
          if (snap.val() === false) {
            vmHome.alert = "Verifique sua internet";
          }else{
            vmHome.alert = "Conectado";
          }
        });
        vmHome.sync = $firebase(vmHome.ref);
        vmHome.data = vmHome.sync.$asArray();      
        vmHome.tarefa={nome:'',pessoa:'',dia:''};
        vmHome.tarefa.dia= new Date();
    }

    function adicionar(){
        if(vmHome.tarefa.dia != null && vmHome.tarefa.dia != undefined){
            vmHome.tarefa.dia = vmHome.tarefa.dia.getTime();
        }
        if(vmHome.tarefa.nome != ""){
            if(vmHome.tarefa.$id == undefined){
                vmHome.data.$add(vmHome.tarefa);
            } if (vmHome.tarefa.$id != undefined){
                vmHome.data.$save(vmHome.tarefa);
            }
            init();
            vmHome.tarefa={nome:'',pessoa:'',dia:''};
        } 
    }
  
  function editar(value){
    vmHome.tarefa=value;
  }

  function excluir(item){
    vmHome.data.$remove(item)
  }
    
  function mostrarModal(ev) {
    $mdDialog.show({
      controller: HomeCtrl,
      contentElement: '#myDialog',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose: true
    });
  } 
  
  function fecharModal() {
      $mdDialog.hide();
  }

}